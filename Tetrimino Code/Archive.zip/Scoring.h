//***************************A5 - Quadris*****************************
//
// Scoring Header
//
//********************************************************************

int scoreRows(int total, int level);
int scoring(int level);